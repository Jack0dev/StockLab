# 🚀 StockLab — Scale-Up Plan (Updated)

> Tích hợp 6 tính năng mới vào kế hoạch gốc, sắp xếp theo độ ưu tiên và dependency.

---

## 🔍 Ghi chú về Data Sources (đã research)

| Nguồn | Tình trạng | Kế hoạch dùng |
|---|---|---|
| **TCBS API** | Undocumented, endpoint thay đổi thường xuyên | Dùng qua Python `vnstock` wrapper hoặc call trực tiếp từ backend 1 lần |
| **CafeF** | Không có API/RSS chính thức | Dùng Backend proxy scrape HTML → parse → cache Redis |
| **VNDirect finfo** | Blocked từ server-side | Không dùng |
| **Gemini/OpenAI** | Có API key → AI Bot | Dùng Gemini API (miễn phí tier) |
| **lightweight-charts** | Đã có trong `package.json` v5.1.0 | Mở rộng tính năng |

> [!IMPORTANT]
> Dữ liệu cổ phiếu thực tế: Dùng **Python script 1 lần** gọi `vnstock` lấy 1–2 năm OHLCV → import vào MySQL. Backend Java không cần phụ thuộc Python sau đó.

---

## Phase 1 — Quick Wins & Fixes (Tuần 1–2)

### 1.1 Fix Security Ngay Lập Tức

**A. OTP không được trả về response body**
```java
// OtpService.java
return ApiResponse.success("Đã gửi OTP đến email.", null); // xóa otp khỏi data
```

**B. Bảo vệ Bot API endpoint**
```java
// SecurityConfig.java
.requestMatchers("/api/bot/**").hasRole("ADMIN")
```

**C. Fix WebSocket URL hardcode**
```jsx
// WebSocketContext.jsx
const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:8080/ws';
webSocketFactory: () => new SockJS(WS_URL)
```

**D. Tắt show-sql production**
```properties
spring.jpa.show-sql=${SHOW_SQL:false}
```

### 1.2 Performance Database

```sql
-- Thêm indexes cho Matching Engine
ALTER TABLE orders ADD INDEX idx_match_buy  (stock_id, side, status, price DESC, created_at ASC);
ALTER TABLE orders ADD INDEX idx_match_sell (stock_id, side, status, price ASC,  created_at ASC);
ALTER TABLE transactions ADD INDEX idx_tx_user_date (user_id, created_at DESC);
```

```java
// Thêm readOnly=true cho tất cả GET services
@Transactional(readOnly = true)
public AdminDashboardResponse getDashboardStats() { ... }
```

### 1.3 Unify WebSocket Client

Hiện có 2 WS client song song. Migrate `hooks/useWebSocket.js` thành wrapper của `WebSocketContext`:
```jsx
export function useWebSocket(topic, onMessage, enabled = true) {
  const { subscribe, connected } = useWsContext();
  useEffect(() => {
    if (!enabled || !connected) return;
    const sub = subscribe(topic, (msg) => onMessage(JSON.parse(msg.body)));
    return () => sub?.unsubscribe();
  }, [topic, enabled, connected]);
  return { connected };
}
```

**Effort tổng Phase 1: 3–5 ngày**

---

## Phase 2 — Core Features Mới (Tuần 3–8)

### 2.1 🕯️ Biểu đồ Nến Nâng Cao (Lightweight Charts v5)

**Tại sao làm sớm**: `lightweight-charts` đã có trong deps, `StockDetailPage` đã có chart cơ bản.

**Frontend — mở rộng `StockDetailPage.jsx`**:

```jsx
// Thêm Drawing Tools toolbar
const DRAWING_TOOLS = ['cursor', 'trendline', 'horizontalLine', 'rectangle', 'fibonacci'];

// Thêm Indicators panel
const INDICATORS = [
  { id: 'MA',   label: 'MA',          params: { period: 20 } },
  { id: 'EMA',  label: 'EMA',         params: { period: 20 } },
  { id: 'BB',   label: 'Bollinger',   params: { period: 20, stdDev: 2 } },
  { id: 'RSI',  label: 'RSI',         params: { period: 14 } },
  { id: 'MACD', label: 'MACD',        params: { fast: 12, slow: 26, signal: 9 } },
  { id: 'VOL',  label: 'Volume',      params: {} },
];
```

**Implementation chi tiết**:
- **MA/EMA/BB**: tính toán từ OHLCV data client-side (không cần backend)
- **RSI/MACD**: tính toán từ close price array
- **Drawing tools**: dùng `lightweight-charts` plugin API hoặc canvas overlay
- **Multi-timeframe**: 1D, 1W, 1M, 3M, 6M, 1Y (gọi backend `GET /stocks/{ticker}/history?range=`)
- **Intraday (1m, 5m, 15m)**: cần thêm intraday data — Phase 3

**Backend — thêm endpoint intraday** (cho Phase 3):
```java
// StockController.java
GET /api/stocks/{ticker}/intraday?interval=1m|5m|15m
```

**Schema bổ sung** (Phase 3):
```sql
CREATE TABLE stock_price_intraday (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  stock_id   BIGINT NOT NULL,
  timestamp  BIGINT NOT NULL,  -- unix timestamp
  open_price DECIMAL(15,2),
  high_price DECIMAL(15,2),
  low_price  DECIMAL(15,2),
  close_price DECIMAL(15,2),
  volume     BIGINT,
  INDEX idx_intraday (stock_id, timestamp DESC),
  FOREIGN KEY (stock_id) REFERENCES stocks(id)
);
```

**Effort: 1 tuần**

---

### 2.2 📊 OrderBook Nâng Cấp Chuyên Nghiệp

**Vấn đề hiện tại** (`OrderBookPage.jsx`): Chỉ hiện bảng BUY/SELL đơn giản, không có depth chart, không có spread indicator.

**Thiết kế mới — 3 sections**:

```
┌─────────────────────────────────────────────────┐
│  [Ticker Selector]  [Spread: 100đ / 0.13%]     │
├──────────────────┬──────────────────────────────┤
│   DEPTH CHART    │  ORDER BOOK TABLE            │
│  (visual bars)   │  SELL (đỏ, giá cao→thấp)     │
│                  │  ─── Last Price ───           │
│                  │  BUY  (xanh, giá cao→thấp)   │
├──────────────────┴──────────────────────────────┤
│  RECENT TRADES (ticker tape — real-time)        │
│  10:32:15  VCB   BUY   1,000  @ 78,500         │
└─────────────────────────────────────────────────┘
```

**Frontend additions**:
- **Depth Chart**: canvas hoặc SVG bar chart — BUY xanh bên trái, SELL đỏ bên phải, cumulative volume
- **Spread indicator**: `spread = bestAsk - bestBid`, `spreadPct = spread/bestBid * 100`
- **Recent Trades ticker**: subscribe `/topic/trades`, filter theo ticker đang xem, hiện 20 trades gần nhất với animation
- **Price flash**: khi giá lastTrade thay đổi → flash xanh (tăng) hoặc đỏ (giảm)
- **Volume bars**: mỗi price level hiển thị volume bar tương đối

**Backend — thêm Recent Trades endpoint**:
```java
// OrderController.java
@GetMapping("/book/{ticker}/trades")
public ResponseEntity<?> getRecentTrades(@PathVariable String ticker,
    @RequestParam(defaultValue = "20") int size) {
    // Query transactions table theo stock, limit size, order by createdAt DESC
}
```

**Effort: 5–7 ngày**

---

### 2.3 📰 Tin Tức Tài Chính

**Chiến lược**: Backend Spring Boot làm proxy scrape/fetch → cache Redis 15 phút → Frontend gọi.

**Data sources**:
1. **CafeF** (`cafef.vn/chung-khoan.chn`) — scrape danh sách bài mới nhất
2. **VnEconomy** — có RSS feed: `vneconomy.vn/chung-khoan.rss`
3. **Investing.com Vietnam** — có RSS feed công khai

**Backend — NewsService.java** (mới):
```java
@Service
public class NewsService {
    // Dùng Jsoup để parse HTML CafeF
    // Dùng RSS parser cho VnEconomy
    // Cache vào Redis với TTL 15 phút
    
    @Scheduled(fixedRate = 900000) // 15 phút
    public void refreshNews() {
        List<NewsItem> news = fetchFromSources();
        redisTemplate.opsForValue().set("news:latest", serialize(news), 15, TimeUnit.MINUTES);
    }
    
    public record NewsItem(String title, String url, String source, 
                           String summary, String imageUrl, LocalDateTime publishedAt) {}
}
```

**Backend — thêm dependency Jsoup**:
```xml
<dependency>
    <groupId>org.jsoup</groupId>
    <artifactId>jsoup</artifactId>
    <version>1.17.2</version>
</dependency>
```

**API mới**:
```
GET /api/news              → 20 tin mới nhất (tổng hợp)
GET /api/news?ticker=VCB   → tin liên quan đến mã cổ phiếu (filter title)
GET /api/news?source=cafef → filter theo nguồn
```

**Frontend — NewsPage.jsx** (mới):
- Route: `/news`
- Layout: card grid, mỗi card có thumbnail, title, source badge, time ago
- Filter tabs: Tất cả / CafeF / VnEconomy / ...
- Search trong title
- Nhúng vào `StockDetailPage`: tab "Tin tức liên quan" filter theo ticker

**Effort: 5–7 ngày**

---

### 2.4 📋 Custom Multi-Watchlist

**Vấn đề hiện tại**: Schema `watchlists` chỉ là flat list user_id + stock_id, không hỗ trợ nhiều danh sách.

**Schema mới**:
```sql
-- Bảng danh mục watchlist
CREATE TABLE watchlist_groups (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT NOT NULL,
  name        VARCHAR(100) NOT NULL,
  color       VARCHAR(7) DEFAULT '#2962ff',  -- hex color
  sort_order  INT DEFAULT 0,
  created_at  DATETIME(6) NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Migrate watchlists cũ: thêm cột group_id
ALTER TABLE watchlists ADD COLUMN group_id BIGINT;
ALTER TABLE watchlists ADD COLUMN sort_order INT DEFAULT 0;
ALTER TABLE watchlists ADD FOREIGN KEY (group_id) REFERENCES watchlist_groups(id);
```

**Migration plan**:
1. Khi user login lần đầu sau update → tạo group mặc định "Danh mục chính"
2. Move toàn bộ watchlist cũ vào group mặc định đó
3. Backward compatible: API cũ vẫn hoạt động, trả về group đầu tiên

**API mới**:
```
POST   /api/watchlist/groups              → tạo group mới
GET    /api/watchlist/groups              → danh sách groups của user
PUT    /api/watchlist/groups/{id}         → đổi tên/màu
DELETE /api/watchlist/groups/{id}         → xóa group (và tất cả items)
PUT    /api/watchlist/groups/reorder      → đổi thứ tự groups
POST   /api/watchlist/groups/{id}/stocks/{ticker} → thêm stock vào group
DELETE /api/watchlist/groups/{id}/stocks/{ticker} → xóa stock khỏi group
```

**Frontend — WatchlistPage.jsx** (refactor):
- Sidebar tabs: danh sách các watchlist groups, có nút "+ Tạo mới"
- Mỗi group hiển thị danh sách cổ phiếu với giá real-time
- Drag & drop reorder cả groups lẫn stocks trong group
- Color picker cho mỗi group

**Effort: 1 tuần**

---

### 2.5 📈 Dữ Liệu Cổ Phiếu Thực Tế (One-time Import)

**Chiến lược**: Python script 1 lần duy nhất → không phụ thuộc runtime.

**Bước 1 — Python script lấy data từ TCBS qua vnstock**:
```python
# scripts/seed_stock_data.py
from vnstock import Vnstock
import mysql.connector
import json

TICKERS = ['VCB','VIC','VHM','HPG','BID','CTG','MBB','TCB',
           'MSN','ACB','FPT','MWG','VJC','SAB','VNM','POW',
           'GAS','REE','SSI','VND','HDB','TPB','VPB','SHB',
           'EIB','STB','PNJ','KDH','VHC','DGC']  # 30 mã blue-chip

stock = Vnstock().stock(symbol='VCB', source='TCBS')

for ticker in TICKERS:
    # Lấy 2 năm OHLCV daily
    df = stock.quote.history(symbol=ticker, start='2023-01-01', end='2025-05-01')
    # Lấy thông tin cơ bản: tên công ty, sàn
    info = stock.company.overview(symbol=ticker)
    # Insert vào MySQL
    ...
```

**Bước 2 — Drop data cũ, import data mới**:
```sql
-- Chạy trước khi import
TRUNCATE TABLE stock_price_history;
TRUNCATE TABLE watchlists;
TRUNCATE TABLE portfolios;
DELETE FROM orders WHERE 1=1;
DELETE FROM transactions WHERE 1=1;
UPDATE stocks SET current_price=0 WHERE 1=1;
-- Sau đó chạy Python script
```

**Bước 3 — Update DataSeeder.java**:
```java
// DataSeeder.java — đánh dấu stocks đã có data thực → không seed random walk nữa
private void seedStocks() {
    if (stockRepository.count() > 0) {
        log.info("Stocks đã có data thực, bỏ qua seed.");
        return;
    }
    // Chỉ seed nếu DB trống (sau lần import Python)
}
```

**Stocks mới** (30 mã thay vì 22):
- Thêm: VPB, HDB, TPB, SHB, EIB, STB, PNJ, KDH, VHC, DGC
- Giá, OHLCV thực tế từ TCBS

**Effort: 2–3 ngày** (bao gồm chạy script + verify data)

---

## Phase 3 — AI & Advanced (Tháng 2–3)

### 3.1 🤖 AI Bot Trợ Lý Đầu Tư

**Stack**: Gemini API (Google) — free tier 15 req/min, 1M tokens/day.

**Backend — AIAssistantService.java** (mới):
```java
@Service
public class AIAssistantService {
    
    // Gemini API integration
    private static final String GEMINI_URL = 
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    
    /**
     * Chat với AI về 1 cổ phiếu cụ thể
     * Context được inject tự động: giá hiện tại, OHLCV 30 ngày, thống kê
     */
    public String chatAboutStock(String ticker, String userMessage, List<ChatMessage> history) {
        String stockContext = buildStockContext(ticker); // lấy từ DB
        String systemPrompt = buildSystemPrompt(stockContext);
        return callGeminiAPI(systemPrompt, history, userMessage);
    }
    
    /**
     * Phân tích tự động 1 cổ phiếu → trả structured JSON
     */
    public StockAnalysis analyzeStock(String ticker) {
        // Tính toán các indicators từ price history
        // Gọi Gemini để diễn giải
        // Trả về: trend, signal, support/resistance, summary
    }
    
    /**
     * Phân tích portfolio của user
     */
    public String analyzePortfolio(Long userId) {
        // Lấy holdings, P&L, diversification
        // Gọi Gemini để đưa ra gợi ý
    }
}
```

**API mới**:
```
POST /api/ai/chat              → { ticker?, message, history[] } → { reply }
GET  /api/ai/analysis/{ticker} → { trend, signal, summary, keyLevels }
GET  /api/ai/portfolio-review  → { review, suggestions }
GET  /api/ai/market-summary    → { overview, hotStocks, sentiment }
```

**Data context inject vào AI**:
```
- Giá hiện tại, thay đổi %, volume
- OHLCV 60 ngày gần nhất
- MA20, MA50, RSI(14), MACD signal
- Top 3 giao dịch lớn nhất gần đây
- Order book depth (bid/ask ratio)
- Tin tức liên quan (từ NewsService)
```

**Frontend — AIChatWidget.jsx** (mới):
- Floating chat button ở góc phải màn hình (như Intercom)
- Chat history trong session
- **Modes**:
  - 💬 Chat tự do (hỏi bất cứ gì về thị trường)
  - 📊 Phân tích cổ phiếu (chọn ticker → auto-analysis)
  - 💼 Review portfolio (phân tích danh mục của tôi)
  - 📰 Tóm tắt tin tức hôm nay

**Nhúng vào StockDetailPage**:
- Tab "AI Analysis" → hiển thị auto-analysis của ticker đó
- Quick buttons: "Xu hướng", "Hỗ trợ/Kháng cự", "Nên mua không?"

**Rate limiting AI**:
```java
// Redis counter: ai:calls:{userId}:{date}
// Limit: 20 calls/user/day (free tier protection)
```

**Effort: 2 tuần**

---

### 3.2 Price Alert System

**Schema**:
```sql
CREATE TABLE price_alerts (
  id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id      BIGINT NOT NULL,
  stock_id     BIGINT NOT NULL,
  target_price DECIMAL(15,2) NOT NULL,
  condition    ENUM('ABOVE','BELOW') NOT NULL,
  is_triggered BIT(1) DEFAULT 0,
  note         VARCHAR(255),
  created_at   DATETIME(6) NOT NULL,
  INDEX idx_alert_active (is_triggered, stock_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (stock_id) REFERENCES stocks(id)
);
```

Tích hợp vào `PostTradeProcessor`: sau khi update stock price → check alerts → gửi WS + email.

**Effort: 3–5 ngày**

---

### 3.3 Leaderboard & Trader Stats

```sql
CREATE TABLE trader_stats (
  user_id      BIGINT PRIMARY KEY,
  total_pnl    DECIMAL(20,2) DEFAULT 0,
  total_trades INT DEFAULT 0,
  win_rate     DECIMAL(5,2) DEFAULT 0,
  updated_at   DATETIME(6),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

`GET /api/leaderboard?period=weekly|monthly|all`

**Effort: 5–7 ngày**

---

### 3.4 Trading Competition

```sql
CREATE TABLE competitions (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(255) NOT NULL,
  initial_capital DECIMAL(20,2) DEFAULT 100000000,
  start_date      DATETIME NOT NULL,
  end_date        DATETIME NOT NULL,
  status          ENUM('UPCOMING','ACTIVE','ENDED') DEFAULT 'UPCOMING'
);
CREATE TABLE competition_participants (
  competition_id  BIGINT NOT NULL,
  user_id         BIGINT NOT NULL,
  virtual_balance DECIMAL(20,2) NOT NULL,
  final_rank      INT,
  PRIMARY KEY (competition_id, user_id)
);
```

**Effort: 2–3 tuần**

---

### 3.5 Persistent Notifications (DB-backed)

```sql
CREATE TABLE notifications (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT NOT NULL,
  type        ENUM('ORDER_FILLED','ORDER_CANCELLED','PRICE_ALERT',
                   'DEPOSIT_COMPLETED','WITHDRAW_COMPLETED') NOT NULL,
  title       VARCHAR(255) NOT NULL,
  content     TEXT,
  is_read     BIT(1) DEFAULT 0,
  navigate_to VARCHAR(255),
  created_at  DATETIME(6) NOT NULL,
  INDEX idx_notif_user (user_id, is_read, created_at DESC),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

**Effort: 4–6 ngày**

---

### 3.6 Rate Limiting & Security

```java
// Redis-based rate limiter
// /api/auth/login      → 5 req/min/IP
// /api/orders          → 30 req/min/user
// /api/wallet/withdraw → 3 req/min/user
// /api/ai/chat         → 20 req/day/user
```

---

## 🗓️ Lộ trình tổng hợp

```
Tuần 1-2:   Phase 1 — Security fixes, DB indexes, unify WS
Tuần 3:     Biểu đồ nến nâng cao (drawing tools + indicators)
Tuần 4:     OrderBook chuyên nghiệp (depth chart + recent trades)
Tuần 5:     Tin tức tài chính (NewsService + NewsPage)
Tuần 6:     Custom Multi-Watchlist
Tuần 7-8:   Import dữ liệu cổ phiếu thực (Python script + verify)
Tháng 2:    AI Bot trợ lý đầu tư (Gemini API)
Tháng 2:    Price Alert + Persistent Notifications
Tháng 3:    Leaderboard + Trader Stats
Tháng 3+:   Trading Competition
```

---

## Dependencies giữa các tính năng

```
Dữ liệu thực (2.5) ──────────────────────────────────► AI Analysis (3.1)
                                                        (cần OHLCV thực)

Biểu đồ nến (2.1) ──► AI Analysis (3.1)
                       (chart context inject vào prompt)

NewsService (2.3) ───► AI Bot (3.1)
                       (tin tức inject vào context)

OrderBook nâng cao (2.2) ─────────────────────────────► AI Analysis (3.1)
                                                        (bid/ask ratio)

Custom Watchlist (2.4) ──► Price Alert (3.2)
                           (alert gắn với watchlist group)
```

---

## Bảng tổng hợp effort & impact

| Tính năng | Effort | User Impact | Priority |
|---|---|---|---|
| Fix security | 3 ngày | 🔴 Critical | P0 |
| DB Indexes | 1 ngày | 🟠 Performance | P0 |
| Unify WS | 2 ngày | 🟡 Stability | P0 |
| Biểu đồ nến | 1 tuần | 🟢 Rất cao | P1 |
| OrderBook nâng cao | 7 ngày | 🟢 Cao | P1 |
| Import data thực | 3 ngày | 🟢 Rất cao | P1 |
| Tin tức | 7 ngày | 🟢 Cao | P2 |
| Custom Watchlist | 1 tuần | 🟡 Trung bình | P2 |
| AI Bot | 2 tuần | 🟢 Rất cao | P3 |
| Price Alert | 5 ngày | 🟢 Cao | P3 |
| Leaderboard | 7 ngày | 🟢 Viral | P3 |
| Competition | 3 tuần | 🟢 Rất viral | P4 |
